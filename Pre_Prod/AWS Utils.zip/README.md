# Extensión de utilidades AWS
Extensión para funcionalidades de AWS, se hizo uso de los iframes internos que se manejan dentro de una pagina web.
